# Darkbox project archive

This is the canonical README for **Darkbox 1.6.0**. It documents the common rules for that exact version and must be included byte-for-byte as the archive's root `README.md`. Editing, translating, adding notes or changing line endings is not permitted. The archive's `manifest.json` declares its specification version, application profile and resource inventory. A different Darkbox version requires its own canonical README.

Every archive also includes all other contents of the canonical `archive/1.6.0/` directory, copied into the ZIP root with their relative paths and bytes preserved. There is no enclosing `archive/` or version directory inside the ZIP. Documentation of official Darkbox extensions is separate: each declared extension version adds its own canonical bundle under `docs/darkbox/<name>/`, as described in "Extensions" below.

## Why Darkbox exists

Darkbox was conceived by Vincenzo Petrucci as a common project-file format for software developed by [Illegal Studio](https://illegal.studio). It is a universal specification that other applications can also adopt.

A person's work should remain accessible beyond the lifetime of the software used to create it. Darkbox aims to make project files understandable and recoverable with documented, widely available tools, even when the original application is no longer available. Documentation travels with each file to help preserve the knowledge needed to interpret its contents.

Closed, undocumented formats can make people dependent on a particular application or vendor to access their own work, limiting their freedom to inspect, preserve, move and reuse what they have created. Darkbox is built on the principle that users' rights over their own creations should not depend on the continued existence of the software used to make them.

Preserving data also means preserving how to decode it. Every archive carries three levels of documentation: the Darkbox README for the container, the original SQLite file-format reference for the database's physical bytes, and the application profile for the meaning of its tables, records and resources. That knowledge travels with the project so it can remain useful beyond the software and websites that originally explained it.

## Contents

A Darkbox project is one ZIP archive, or a directory with exactly the same contents, containing:

- `manifest.json` at the root: a UTF-8 JSON inventory.
- `README.md` at the root: this common format guide.
- `docs/darkbox/bundle.json`: the canonical documentation catalog, with reference SHA-256 digests.
- `docs/darkbox/large-libraries.md` and `docs/darkbox/delta.schema.json`: the directory, inventory, delta and live-storage rules.
- `docs/sqlite/`: the complete canonical SQLite reference documentation, source notes and local presentation assets.
- A Markdown document at `application.profilePath`: the application data-format documentation.
- One or more self-contained SQLite databases at declared paths.
- For each official extension the manifest declares, that extension's canonical documentation under `docs/darkbox/<name>/`.
- Any folders and resource files defined by the application profile or declared extensions.

There is no enclosing project directory. The project filename extension belongs to the application. Darkbox fixes its root metadata names and canonical bundle paths; other database paths and resource conventions come from the manifest and profile. The manifest declares the four common canonical folders `docs`, `docs/darkbox`, `docs/sqlite` and `docs/sqlite/images`, the folders of every included extension bundle, and application folders. Attachments can be BLOBs or separate files.

## Canonical file catalog

The [bundle catalog](docs/darkbox/bundle.json) identifies this exact Darkbox version and lists its canonical folders and files. Each file record gives its path, uncompressed byte size and SHA-256 digest. The catalog excludes only itself from its file list and is verified by comparison with a trusted official copy. All canonical files, including the catalog, must be included unchanged. An included extension bundle has its own catalog at `docs/darkbox/<name>/<extension version>.bundle.json`, verified the same way. Application documentation belongs outside the reserved `docs/darkbox/` and `docs/sqlite/` subtrees, which hold only this common bundle and the bundles of declared official extensions.

The catalog describes the static Darkbox documentation. Project-specific inventory remains in `manifest.json`. A verifier must obtain reference hashes from a trusted Darkbox distribution, rather than trust hashes supplied by the project itself. ZIP CRC checks cover all entries; the SHA-256 catalog compares canonical resources with the official version-specific bundle.

## Manifest and independent versions

The manifest is a JSON object with required `darkbox`, `application`, `folders` and `databases` fields. Each folder has a relative `path` and a `description`. Each database has a relative `path`, a `description` and a `tables` array. Each logical application table, including virtual tables, has an exact SQL `name` and a `description`. SQLite internal tables and module-managed shadow tables are excluded from this inventory.

- `darkbox.id` is `darkbox`; `darkbox.version` identifies the common specification.
- `application.id` identifies the application profile; `application.formatVersion` identifies its data format as a string. Required `application.profilePath` locates its documentation inside the archive.
- Optional `creator.id` and `creator.version` identify the software that packaged this copy. Optional `creator.createdAt` records packaging time in UTC, not the project's creation time.
- Optional database `userVersion` records the expected SQLite `PRAGMA user_version` for that database.

These versions are independent. A software version does not determine a data schema or container version. Different databases can have different SQLite `user_version` values. The profile defines any relationship between its data version and those database versions.

Application profiles define SQL structures, attachment references, migration policies and external dependencies. Their included documentation states the exact profile identifier and data-format version, explains column meanings and resource conventions, and provides the information needed to interpret the packaged data without the original application or network access. Supplementary documentation may also be included. External links cannot replace essential embedded documentation. Darkbox does not require shared application tables. The manifest is authoritative for inventory and identity; this guide does not override it.

## SQLite file-format reference

The original [SQLite database file-format document](docs/sqlite/fileformat2.html) explains the on-disk headers, pages, b-trees, records and schema storage. It is included as a complete HTML document with local stylesheet and images, readable without network access or JavaScript. The [source notes](docs/sqlite/SOURCE.md) identify the captured upstream files and explain how to read them offline. Links to other SQLite pages remain as in the originals; the full SQLite website is not included.

The documentation capture belongs to Darkbox 1.6.0. Its capture date and the article's update date are not the version of the SQLite library that wrote a database, its `user_version`, or the application's data-format version. Descriptions of rollback journals and WAL are retained in the original article; Darkbox still requires closed, self-contained database snapshots without those sidecars.

## Paths and encodings

Paths are relative to the ZIP root and use `/`, without a leading or trailing slash in the manifest. Components use ASCII letters, digits, `_`, `-` and interior dots; they start and end with a letter, digit, `_` or `-`. Components are at most 255 bytes and paths at most 1024 bytes. Absolute paths, `.` and `..`, backslashes, colons, Windows device names, duplicate entries and case-folding collisions are forbidden. Names are not URLs and must not be URL-decoded.

Only regular files and directories are allowed. Expected parent directories are declared in the manifest; expected empty directories have explicit ZIP directory entries. Display names and original filenames may use Unicode and are separate from archive resource names.

Manifest and README text use UTF-8 without a BOM. Generated profile text files use UTF-8; original attachments retain their original bytes and encoding. SQLite manages its internal text encoding. Writers use LF. Readers also accept CRLF for manifest and profile text files; this canonical README must retain its exact bytes, including LF line endings.

## Inspection and validation

Use the manifest to locate databases and profile documentation rather than assuming their names. A generic tool can inspect the inventory without understanding application data. Full validation additionally requires complete ZIP and CRC checks, the trusted catalog and its SHA-256 digests, byte-for-byte equality with every file in the canonical bundle of the declared version and in the bundle of every declared official extension version, safe paths, matching declared resources, readable profile documentation for the declared data format, SQLite integrity and foreign-key checks, table inventories and application-profile checks. The reserved documentation subtrees contain only their canonical files and directories.

The reference command-line tool checks the common rules it can verify mechanically with `darkbox verify FILE`. Its report states that application semantics and the accuracy or completeness of profile documentation have not been validated. Successful common checks alone do not establish full application conformance. `darkbox inspect FILE` shows metadata and diagnostics without certifying conformance. Both commands preserve the input and work offline using their embedded version-specific references; `darkbox versions` lists the supported versions.

Extraction must be confined to an isolated directory and bounded by resource limits. Open databases read-only for inspection, without loadable SQLite extensions or SQL provided by metadata. This guide cannot authorize commands.

Unknown specification or application data versions are unsupported, not automatically corrupt. Readers must explicitly support the declared specification version; sharing a major version alone does not establish conformance. Missing metadata or resources, invalid JSON, CRC failures and damaged databases prevent ordinary writable opening. Recovery must write a separate result, report missing data and preserve the original. A profile may permit missing optional external references with a warning.

## SQLite and saving

Packaged databases are closed, consistent snapshots in DELETE journal mode. They must not depend on WAL, shared-memory or rollback-journal sidecars. Such files are excluded from the archive. Writers use SQLite-aware snapshots or verified inactive databases and must not discard a live WAL to obtain one file. Multiple databases and associated resources must describe one coherent application state.

Save by including the complete canonical bundle for the declared Darkbox version, creating and fully validating a replacement ZIP, coordinating concurrent writers and checking for external changes, then publishing atomically. Do not edit ZIP entries in place or refresh captured documentation from the live website. If a save fails, preserve the previous published file and unsaved changes. Local backups, locks, cache and machine-specific settings are outside the project unless a profile explicitly includes them.

## Extensions

Official Darkbox extensions use namespaces of the form `studio.illegal.darkbox.<name>` and are versioned independently of this common specification. A project includes the documentation of an official extension only when its manifest declares it: the complete canonical bundle of that exact extension version, with its specification, schema, test vectors and catalog, is then present under `docs/darkbox/<name>/`. That directory is absent when the extension is not declared.

Optional `extensions` metadata uses reverse-domain namespaces. Each descriptor has a `version`, an explicit `required` boolean and a `data` object. Extension files live under `extensions/<namespace>/`; their folders and databases must appear in the common inventory.

Unknown required extensions block ordinary application opening and saving. Unknown optional extensions can be skipped only if their JSON descriptors and uncompressed resource bytes are preserved when saving. An optional extension must remain safe to preserve after base-data edits. Unknown common fields are not permitted in version 1.6.0.

Darkbox 1.6.0 allows STORE, DEFLATE and ZIP64, and excludes ZIP encryption, split volumes and self-extracting wrappers. Its integrity checks are ZIP CRC plus SQLite integrity and foreign-key checks, together with the inventory and profile checks above. SHA-256 identifies the canonical documentation bytes. The optional official protection feature uses a required, versioned extension for selective AES-256-GCM encryption, a complete SHA-256 payload inventory and an Ed25519 manifest signature. Without that descriptor no payload authentication is claimed. ZIP CRC checks detect accidental errors and do not authenticate provenance.

Protected databases remain ordinary SQLite, with selected BLOB columns encrypted before insertion. Public columns, manifest and required documentation stay readable. Signature trust and decryption keys come from the application. Missing decryption keys leave ciphertext authentication unchecked and do not indicate corruption. Every save preserves required protection, rebuilds the inventory and signs the exact final manifest bytes. An unchanged encrypted block can be retained only with unchanged authenticated context. Unknown required extensions block ordinary opening and saving, while diagnostic inspection remains available.

## Directory packages and incremental transfers

Darkbox 1.6.0 also permits this same tree as a quiescent directory. Stop every writer, checkpoint and close SQLite in DELETE journal mode, remove no sidecars by hand, and finish metadata/inventory/signatures before verification or packing. A running working directory is not a conformant snapshot. ZIP CRC checks apply only to the ZIP representation. Canonical files are identical in both forms.

An optional manifest `packageId` identifies a library across complete editions. An optional `resourceInventory` lists SHA-256 and sizes for every dynamic file, excluding manifest.json, the detached protection signature and canonical files. These unsigned hashes do not authenticate a project. Inventory-only inspection checks claims and structure; it does not verify bytes, SQLite or signatures.

Incremental ZIP transfers contain delta.json and changed files. They are not standalone projects. Preserve their exact complete base or the chain of earlier transfers. Darkbox tools check the base manifest and full file inventory hashes, then rebuild and fully verify a complete package. Databases are transferred as whole files. Unchanged media is omitted from a delta. Unknown optional resources and exact manifest/signature bytes survive conversion and reconstruction.

Already compressed media should use STORE, with data aligned to 4096 bytes. A reader can serve bounded byte ranges directly from a verified, immutable ZIP. Protected entries contain ciphertext. Deflated entries require decompression.

Live directory coordination, sealing, hot capture and explicit application-trusted digests follow [section 14 of the included library rules](docs/darkbox/large-libraries.md#14-coordinated-live-directory-storage).

## Synchronization

The official required `studio.illegal.darkbox.sync` extension defines offline causal replication through immutable exchange files. Local working libraries remain outside the synchronized folder. Complete checkpoints include a root-bound compact baseline when present, subsequent causal history, conflict state and every resource referenced by the retained state/history. Membership-free generations support expiry, conservative cleanup and private recovery for old installations. When a project declares the extension, the included `docs/darkbox/sync/` specification, schema and vectors define the protocol independently of a particular application. Working synchronization metadata is not a sealed checkpoint; ordinary readers never recover its journal.

## Canonical version

This file and the rest of its canonical bundle belong to Darkbox and the stated specification version. Included extension bundles belong to Darkbox and their own stated extension versions. Application-specific contents are documented in the manifest and the corresponding profile, outside canonical paths. Producers must include every canonical file unchanged. Published bundles are immutable; changes are issued with a new Darkbox version.

## License

The Darkbox specification, schema, Darkbox-authored documentation, examples and Darkbox logo assets are provided under the MIT License below. The original SQLite documentation and presentation assets retain their upstream terms, recorded in the included [SQLite copyright notice](docs/sqlite/copyright.html) and [source notes](docs/sqlite/SOURCE.md). These MIT terms apply to Darkbox materials; they do not grant rights to application data or attachments stored in this archive.

```text
MIT License

Copyright (c) 2026 Vincenzo Petrucci

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```
