# org.example.conformance, format 1

Profile identifier: org.example.conformance. Data-format version: 1.

The database data/project.sqlite has SQLite user_version 1 and one table.

- notes.id: stable unique TEXT identifier.
- notes.title: UTF-8 title, never NULL.

There are no attachments, external dependencies or derived caches.
