# org.example.conformance, format 1

Profile identifier: org.example.conformance. Data-format version: 1.

The database data/project.sqlite has SQLite user_version 1 and one table.

- notes.id: stable unique TEXT identifier, never changed after creation.
- notes.title: public UTF-8 title, never NULL.
- notes.secret: NULL, or a protected BLOB whose plaintext is UTF-8 text.

assets/public.txt is public UTF-8 text. assets/private.bin is a protected file whose plaintext is UTF-8 text.
